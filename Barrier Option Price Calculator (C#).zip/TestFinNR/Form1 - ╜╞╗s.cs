﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

using DFinNR;

namespace TestFinNR
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("感謝您的使用。");
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double S = double.Parse(textBox1.Text);
            double K = double.Parse(textBox2.Text);
            double time = double.Parse(textBox3.Text);
            double sigma = double.Parse(textBox4.Text);
            double r = double.Parse(textBox5.Text);
            double H = double.Parse(textBox11.Text);

            double vanilla_call_price = BSMOption.option_price_call_black_scholes(S, K, r, sigma,time);
            callopt.Text = vanilla_call_price.ToString("F6");

            double vanilla_put_price = BSMOption.option_price_put_black_scholes(S, K, r, sigma, time);
            putopt.Text = vanilla_put_price.ToString("F6");

            double barrier_price_cdi = BSMOption_Barrier.call_price_down_and_in(S, K, H, r, sigma, time);
            cdi.Text = barrier_price_cdi.ToString("F6");

            double barrier_price_cdo = BSMOption_Barrier.call_price_down_and_out(S, K, H, r, sigma, time);
            cdo.Text = barrier_price_cdo.ToString("F6");

            double barrier_price_cui = BSMOption_Barrier.call_price_up_and_in(S, K, H, r, sigma, time);
            cui.Text = barrier_price_cui.ToString("F6");

            double barrier_price_cuo = BSMOption_Barrier.call_price_up_and_out(S, K, H, r, sigma, time);
            cuo.Text = barrier_price_cuo.ToString("F6");

            double barrier_price_pdi = BSMOption_Barrier.put_price_down_and_in(S, K, H, r, sigma, time);
            pdi.Text = barrier_price_pdi.ToString("F6");

            double barrier_price_pdo = BSMOption_Barrier.put_price_down_and_out(S, K, H, r, sigma, time);
            pdo.Text = barrier_price_pdo.ToString("F6");

            double barrier_price_pui = BSMOption_Barrier.put_price_up_and_in(S, K, H, r, sigma, time);
            pui.Text = barrier_price_pui.ToString("F6");

            double barrier_price_puo = BSMOption_Barrier.put_price_up_and_out(S, K, H, r, sigma, time);
            puo.Text = barrier_price_puo.ToString("F6");

            MessageBox.Show("計算完成。");
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            double S = double.Parse(textBox1.Text);
            double K = double.Parse(textBox2.Text);
            double time = double.Parse(textBox3.Text);
            double sigma = double.Parse(textBox4.Text);
            double r = double.Parse(textBox5.Text);
            double[] data1 = new double[500];
            /*for (int i = 0; i < 100; i++)
            {
                data1[i] = BSMOption.option_price_delta_call_black_scholes(i, K, r, sigma, time);
            }
            */
            double temp = S * 0.4;
            double upper = S * 1.6;

            while (temp < upper)
            {
                chart1.Series["Delta(Call)"].Points.AddXY(temp, BSMOption.option_price_delta_call_black_scholes(temp, K, r, sigma, time));
                chart1.Series["Delta(Put)"].Points.AddXY(temp, BSMOption.option_price_delta_put_black_scholes(temp, K, r, sigma, time));
                chart2.Series["Gamma(Call)"].Points.AddXY(temp, BSMOption.option_price_gamma_call_black_scholes(temp, K, r, sigma, time));
                chart2.Series["Gamma(Put)"].Points.AddXY(temp, BSMOption.option_price_gamma_put_black_scholes(temp, K, r, sigma, time));
                chart3.Series["Theta(Call)"].Points.AddXY(temp, BSMOption.option_price_theta_call_black_scholes(temp, K, r, sigma, time));
                chart3.Series["Theta(Put)"].Points.AddXY(temp, BSMOption.option_price_theta_put_black_scholes(temp, K, r, sigma, time));
                chart5.Series["Vega(Call)"].Points.AddXY(temp, BSMOption.option_price_vega_call_black_scholes(temp, K, r, sigma, time));
                chart5.Series["Vega(Put)"].Points.AddXY(temp, BSMOption.option_price_vega_put_black_scholes(temp, K, r, sigma, time));
                chart4.Series["Rho(Call)"].Points.AddXY(temp, BSMOption.option_price_rho_call_black_scholes(temp, K, r, sigma, time));
                chart4.Series["Rho(Put)"].Points.AddXY(temp, BSMOption.option_price_rho_put_black_scholes(temp, K, r, sigma, time));
                temp = temp + 0.5;
            }
            MessageBox.Show("繪圖完成！");
            /*for(int i = 0; i < 100; i++)
            {
                chart1.Series["Delta"].Points.AddXY(i, data1[i]);
            }
            */

            //chart1.Series["Series1"].Points.AddXY("10", "20");
            //chart1.Series["Series1"].Points.AddXY("20", "50");
            //chart1.Series["Series1"].Points.AddXY("30", "90");
        }
    }
}
