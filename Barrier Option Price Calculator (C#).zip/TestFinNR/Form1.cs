﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;

using DFinNR;

namespace TestFinNR
{


    public partial class Form1 : Form
    {
        public Form1()
        {
            //初始化
            InitializeComponent(); 

            //新增元素到"Option Type"的下拉式選單
            comboBox1.Items.Add("Put");
            comboBox1.Items.Add("Call");

            //新增元素到"Option Type"的下拉式選單
            comboBox2.Items.Add("Delta");
            comboBox2.Items.Add("Gamma"); 
            comboBox2.Items.Add("Vega");
            comboBox2.Items.Add("Theta"); 
            comboBox2.Items.Add("Rho");
            
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("感謝您的使用。", "提示"); //點擊"Close"所顯示的視窗
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string thelabel = (string)comboBox1.SelectedItem;
            
            //下拉式選單判斷
            if (thelabel == "Put")
            {
                try
                {
                    double S = double.Parse(textBox1.Text);
                    double K = double.Parse(textBox2.Text);
                    double time = double.Parse(textBox3.Text);
                    double sigma = double.Parse(textBox4.Text);
                    double r = double.Parse(textBox5.Text);
                    double H = double.Parse(textBox11.Text);

                    double vanilla_put_price = BSMOption.option_price_put_black_scholes(S, K, r, sigma, time);
                    callopt.Text = vanilla_put_price.ToString("F6");

                    double barrier_price_cdi = BSMOption_Barrier.put_price_down_and_in(S, K, H, r, sigma, time);
                    DI.Text = barrier_price_cdi.ToString("F6");

                    double barrier_price_cdo = BSMOption_Barrier.put_price_down_and_out(S, K, H, r, sigma, time);
                    DO.Text = barrier_price_cdo.ToString("F6");

                    double barrier_price_cui = BSMOption_Barrier.put_price_up_and_in(S, K, H, r, sigma, time);
                    UI.Text = barrier_price_cui.ToString("F6");

                    double barrier_price_cuo = BSMOption_Barrier.put_price_up_and_out(S, K, H, r, sigma, time);
                    UO.Text = barrier_price_cuo.ToString("F6");


                    MessageBox.Show("計算完成。", "提示"); //點擊"Calculate"所顯示的視窗
                }
                catch (FormatException)
                {
                    MessageBox.Show("輸入的值非數字，請重新輸入", "提示");
                }
            }

            else if (thelabel == "Call")  
            {
                try
                {
                    double S = double.Parse(textBox1.Text);
                    double K = double.Parse(textBox2.Text);
                    double time = double.Parse(textBox3.Text);
                    double sigma = double.Parse(textBox4.Text);
                    double r = double.Parse(textBox5.Text);
                    double H = double.Parse(textBox11.Text);

                    double vanilla_call_price = BSMOption.option_price_call_black_scholes(S, K, r, sigma, time);
                    callopt.Text = vanilla_call_price.ToString("F6");

                    double barrier_price_cdi = BSMOption_Barrier.call_price_down_and_in(S, K, H, r, sigma, time);
                    DI.Text = barrier_price_cdi.ToString("F6");

                    double barrier_price_cdo = BSMOption_Barrier.call_price_down_and_out(S, K, H, r, sigma, time);
                    DO.Text = barrier_price_cdo.ToString("F6");

                    double barrier_price_cui = BSMOption_Barrier.call_price_up_and_in(S, K, H, r, sigma, time);
                    UI.Text = barrier_price_cui.ToString("F6");

                    double barrier_price_cuo = BSMOption_Barrier.call_price_up_and_out(S, K, H, r, sigma, time);
                    UO.Text = barrier_price_cuo.ToString("F6");


                    MessageBox.Show("計算完成。", "提示");
                }
                catch (FormatException)
                {
                    MessageBox.Show("輸入的值非數字，請重新輸入", "提示"); //防呆設計
                }
            }

            else
            {
                MessageBox.Show("您還沒選擇Option的種類喔~","提示"); //防呆設計
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            string thelabel = (string)comboBox2.SelectedItem;

            //初始化圖表
            while (chart1.Series.Count > 0)
                chart1.Series.RemoveAt(0);
            
            //新增兩個折線圖
            chart1.Series.Add("Call(European)");
            chart1.Series.Add("Put(European)");
            chart1.Series["Call(European)"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart1.Series["Put(European)"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;

            chart1.Series["Call(European)"].BorderWidth = 4;
            chart1.Series["Put(European)"].BorderWidth = 4;

            chart1.ChartAreas[0].AxisX.Minimum = 0;

            if (thelabel == "Delta")
            {
                try
                {
                    double S = double.Parse(textBox1.Text); //現貨價
                    double K = double.Parse(textBox2.Text); //履約價
                    double time = double.Parse(textBox3.Text); //距離到期剩餘年數
                    double sigma = double.Parse(textBox4.Text); //波動率
                    double r = double.Parse(textBox5.Text); //無風險利率
                    double H = double.Parse(textBox11.Text); //指定的障礙價格
                    double[] data1 = new double[500];
                    /*for (int i = 0; i < 100; i++)  //使用 for 迴圈繪圖，但圖形會是間斷型，不妥
                    {
                        data1[i] = BSMOption.option_price_delta_call_black_scholes(i, K, r, sigma, time);
                    }
                    */
                    double temp = S * 0.0;
                    double upper = S * 2.5;

                    //繪圖
                    while (temp < upper)
                    {
                        chart1.Series["Call(European)"].Points.AddXY(temp, BSMOption.option_price_delta_call_black_scholes(temp, K, r, sigma, time));
                        chart1.Series["Put(European)"].Points.AddXY(temp, BSMOption.option_price_delta_put_black_scholes(temp, K, r, sigma, time));

                        temp = temp + 0.5;
                    }
                    MessageBox.Show("繪圖完成！");

                }
                catch (FormatException)
                {
                    MessageBox.Show("輸入的值非數字，請重新輸入", "提示"); //防呆設計
                }
            }

            else if (thelabel == "Gamma")
            {
                try
                {
                    double S = double.Parse(textBox1.Text); //現貨價
                    double K = double.Parse(textBox2.Text); //履約價
                    double time = double.Parse(textBox3.Text); //距離到期剩餘年數
                    double sigma = double.Parse(textBox4.Text); //波動率
                    double r = double.Parse(textBox5.Text); //無風險利率
                    double H = double.Parse(textBox11.Text); //指定的障礙價格
                    double[] data1 = new double[500];

                    double temp = S * 0.0;
                    double upper = S * 2.5;

                    //繪圖
                    while (temp < upper)
                    {
                        chart1.Series["Call(European)"].Points.AddXY(temp, BSMOption.option_price_gamma_call_black_scholes(temp, K, r, sigma, time));
                        chart1.Series["Put(European)"].Points.AddXY(temp, BSMOption.option_price_gamma_put_black_scholes(temp, K, r, sigma, time));

                        temp = temp + 0.5;
                    }
                    MessageBox.Show("繪圖完成！");

                }
                catch (FormatException)
                {
                    MessageBox.Show("輸入的值非數字，請重新輸入", "提示"); //防呆設計
                }
            }

            else if (thelabel == "Vega")
            {
                try
                {
                    double S = double.Parse(textBox1.Text); //現貨價
                    double K = double.Parse(textBox2.Text); //履約價
                    double time = double.Parse(textBox3.Text); //距離到期剩餘年數
                    double sigma = double.Parse(textBox4.Text); //波動率
                    double r = double.Parse(textBox5.Text); //無風險利率
                    double H = double.Parse(textBox11.Text); //指定的障礙價格
                    double[] data1 = new double[500];

                    double temp = S * 0.0;
                    double upper = S * 2.5;

                    //繪圖
                    while (temp < upper)
                    {
                        chart1.Series["Call(European)"].Points.AddXY(temp, BSMOption.option_price_vega_call_black_scholes(temp, K, r, sigma, time));
                        chart1.Series["Put(European)"].Points.AddXY(temp, BSMOption.option_price_vega_put_black_scholes(temp, K, r, sigma, time));

                        temp = temp + 0.5;
                    }
                    MessageBox.Show("繪圖完成！");

                }
                catch (FormatException)
                {
                    MessageBox.Show("輸入的值非數字，請重新輸入", "提示"); //防呆設計
                }
            }

            else if (thelabel == "Theta")
            {
                try
                {
                    double S = double.Parse(textBox1.Text); //現貨價
                    double K = double.Parse(textBox2.Text); //履約價
                    double time = double.Parse(textBox3.Text); //距離到期剩餘年數
                    double sigma = double.Parse(textBox4.Text); //波動率
                    double r = double.Parse(textBox5.Text); //無風險利率
                    double H = double.Parse(textBox11.Text); //指定的障礙價格
                    double[] data1 = new double[500];

                    double temp = S * 0.0;
                    double upper = S * 2.5;

                    //繪圖
                    while (temp < upper)
                    {
                        chart1.Series["Call(European)"].Points.AddXY(temp, BSMOption.option_price_theta_call_black_scholes(temp, K, r, sigma, time));
                        chart1.Series["Put(European)"].Points.AddXY(temp, BSMOption.option_price_theta_put_black_scholes(temp, K, r, sigma, time));

                        temp = temp + 0.5;
                    }
                    MessageBox.Show("繪圖完成！");

                }
                catch (FormatException)
                {
                    MessageBox.Show("輸入的值非數字，請重新輸入", "提示"); //防呆設計
                }
            }

            else if (thelabel == "Rho")
            {
                try
                {
                    double S = double.Parse(textBox1.Text); //現貨價
                    double K = double.Parse(textBox2.Text); //履約價
                    double time = double.Parse(textBox3.Text); //距離到期剩餘年數
                    double sigma = double.Parse(textBox4.Text); //波動率
                    double r = double.Parse(textBox5.Text); //無風險利率
                    double H = double.Parse(textBox11.Text); //指定的障礙價格
                    double[] data1 = new double[500];

                    double temp = S * 0.0;
                    double upper = S * 2.5;

                    //繪圖
                    while (temp < upper)
                    {
                        chart1.Series["Call(European)"].Points.AddXY(temp, BSMOption.option_price_rho_call_black_scholes(temp, K, r, sigma, time));
                        chart1.Series["Put(European)"].Points.AddXY(temp, BSMOption.option_price_rho_put_black_scholes(temp, K, r, sigma, time));

                        temp = temp + 0.5;
                    }
                    MessageBox.Show("繪圖完成！");

                }
                catch (FormatException)
                {
                    MessageBox.Show("輸入的值非數字，請重新輸入", "提示"); //防呆設計
                }
            }

            else
            {
                MessageBox.Show("您還沒選擇Greek Letters的種類喔~", "提示"); //防呆設計
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) //下拉式選單(選擇權類型)
        {
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList; //設定下拉式選單樣式
        }
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e) //下拉式選單(Greek Letters)
        {
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList; //設定下拉式選單樣式
        }
        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void chart1_Click_1(object sender, EventArgs e)
        {

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string thelabel = (string)comboBox1.SelectedItem;

            //初始化圖表
            while (chart2.Series.Count > 0)
                chart2.Series.RemoveAt(0);

            //新增兩個折線圖
            chart2.Series.Add("European");
            chart2.Series.Add("Barrier_DI");
            chart2.Series.Add("Barrier_DO");
            chart2.Series.Add("Barrier_UI");
            chart2.Series.Add("Barrier_UO");

            chart2.Series["European"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart2.Series["Barrier_DI"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart2.Series["Barrier_DO"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart2.Series["Barrier_UI"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            chart2.Series["Barrier_UO"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;

            chart2.Series["European"].Color = Color.Red;
            chart2.Series["Barrier_DI"].Color = Color.Blue;
            chart2.Series["Barrier_DO"].Color = Color.Green;
            chart2.Series["Barrier_UI"].Color = Color.Yellow;
            chart2.Series["Barrier_UO"].Color = Color.Purple;

            chart2.Series["European"].BorderWidth = 4;
            chart2.Series["Barrier_DI"].BorderWidth = 4;
            chart2.Series["Barrier_DO"].BorderWidth = 4;
            chart2.Series["Barrier_UI"].BorderWidth = 4;
            chart2.Series["Barrier_UO"].BorderWidth = 4;

            chart2.ChartAreas[0].AxisX.Minimum = 0;

            if (thelabel == "Put")
            {
                try
                {
                    double S = double.Parse(textBox1.Text); //現貨價
                    double K = double.Parse(textBox2.Text); //履約價
                    double time = double.Parse(textBox3.Text); //距離到期剩餘年數
                    double sigma = double.Parse(textBox4.Text); //波動率
                    double r = double.Parse(textBox5.Text); //無風險利率
                    double H = double.Parse(textBox11.Text); //指定的障礙價格
                    double[] data1 = new double[500];
                    /*for (int i = 0; i < 100; i++)  //使用 for 迴圈繪圖，但圖形會是間斷型，不妥
                    {
                        data1[i] = BSMOption.option_price_delta_call_black_scholes(i, K, r, sigma, time);
                    }
                    */
                    double temp = S * 0.0;
                    double upper = S * 2.5;

                    //繪圖
                    while (temp < upper)
                    {
                        chart2.Series["European"].Points.AddXY(temp, BSMOption.option_price_put_black_scholes(temp, K, r, sigma, time));
                        chart2.Series["Barrier_DI"].Points.AddXY(temp, BSMOption_Barrier.put_price_down_and_in(temp, K, H, r, sigma, time));
                        chart2.Series["Barrier_DO"].Points.AddXY(temp, BSMOption_Barrier.put_price_down_and_out(temp, K, H, r, sigma, time));
                        chart2.Series["Barrier_UI"].Points.AddXY(temp, BSMOption_Barrier.put_price_up_and_in(temp, K, H, r, sigma, time));
                        chart2.Series["Barrier_UO"].Points.AddXY(temp, BSMOption_Barrier.put_price_up_and_out(temp, K, H, r, sigma, time));

                        temp = temp + 0.5;
                    }
                    MessageBox.Show("繪圖完成！");

                }
                catch (FormatException)
                {
                    MessageBox.Show("輸入的值非數字，請重新輸入", "提示"); //防呆設計
                }
            }

            else if (thelabel == "Call")
            {
                try
                {
                    double S = double.Parse(textBox1.Text); //現貨價
                    double K = double.Parse(textBox2.Text); //履約價
                    double time = double.Parse(textBox3.Text); //距離到期剩餘年數
                    double sigma = double.Parse(textBox4.Text); //波動率
                    double r = double.Parse(textBox5.Text); //無風險利率
                    double H = double.Parse(textBox11.Text); //指定的障礙價格
                    double[] data1 = new double[500];
                    /*for (int i = 0; i < 100; i++)  //使用 for 迴圈繪圖，但圖形會是間斷型，不妥
                    {
                        data1[i] = BSMOption.option_price_delta_call_black_scholes(i, K, r, sigma, time);
                    }
                    */
                    double temp = S * 0.0;
                    double upper = S * 2.5;

                    //繪圖
                    while (temp < upper)
                    {
                        chart2.Series["European"].Points.AddXY(temp, BSMOption.option_price_call_black_scholes(temp, K, r, sigma, time));
                        chart2.Series["Barrier_DI"].Points.AddXY(temp, BSMOption_Barrier.call_price_down_and_in(temp, K, H, r, sigma, time));
                        chart2.Series["Barrier_DO"].Points.AddXY(temp, BSMOption_Barrier.call_price_down_and_out(temp, K, H, r, sigma, time));
                        chart2.Series["Barrier_UI"].Points.AddXY(temp, BSMOption_Barrier.call_price_up_and_in(temp, K, H, r, sigma, time));
                        chart2.Series["Barrier_UO"].Points.AddXY(temp, BSMOption_Barrier.call_price_up_and_out(temp, K, H, r, sigma, time));

                        temp = temp + 0.5;
                    }
                    MessageBox.Show("繪圖完成！");

                }
                catch (FormatException)
                {
                    MessageBox.Show("輸入的值非數字，請重新輸入", "提示"); //防呆設計
                }
            }

            else
            {
                MessageBox.Show("您還沒選擇Option的種類喔~", "提示"); //防呆設計
            }
        }
    }
}
