﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFinNR
{   
    public static class BSMOption
    {
        /// Black Scholes formula //
        public static double option_price_call_black_scholes(double S, double K,
            double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            return S * DStat.NormDist(d1) - K * Math.Exp(-r * time) * DStat.NormDist(d2);
        }

        public static double option_price_put_black_scholes(double S, double K,
            double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            return K * Math.Exp(-r * time) * DStat.NormDist(-d2) - S * DStat.NormDist(-d1);
        }

        public static double option_price_delta_call_black_scholes(double S, 
            double K, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) 
                + 0.5 * sigma * time_sqrt;
            double delta = DStat.NormDist(d1);
            return delta;
        }

        public static double option_price_delta_put_black_scholes(double S, 
            double K, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) 
                + 0.5 * sigma * time_sqrt;
            double delta = -DStat.NormDist(-d1);
            return delta;
        }

        public static double option_price_gamma_call_black_scholes(double S,
            double K, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt)
                + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double gamma = DStat.NormDist(d1) / (S * sigma * time_sqrt);
            return gamma;
        }
        public static double option_price_gamma_put_black_scholes(double S,
            double K, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt)
                + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double gamma = DStat.NormDist(d1) / (S * sigma * time_sqrt);
            return gamma;
        }
        public static double option_price_theta_call_black_scholes(double S,
            double K, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt)
                + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double theta = -(S * sigma * DStat.NormDist(d1)) / (2 * time_sqrt)
                - r * K * Math.Exp(-r * time) * DStat.NormDist(d2);
            return theta;
        }
        public static double option_price_theta_put_black_scholes(double S,
            double K, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt)
                + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double theta = -(S * sigma * DStat.NormDist(d1)) / (2 * time_sqrt)
                + r * K * Math.Exp(-r * time) * DStat.NormDist(-d2);
            return theta;
        }
        public static double option_price_vega_call_black_scholes(double S,
            double K, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt)
                + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double vega = S * time_sqrt * DStat.NormDist(d1);
            return vega;
        }
        public static double option_price_vega_put_black_scholes(double S,
            double K, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt)
                + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double vega = S * time_sqrt * DStat.NormDist(d1);
            return vega;
        }
        public static double option_price_rho_call_black_scholes(double S,
            double K, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt)
                + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double rho = K * time * Math.Exp(-r * time) * DStat.NormDist(d2);
            return rho;
        }
        public static double option_price_rho_put_black_scholes(double S,
            double K, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt)
                + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double rho = -K * time * Math.Exp(-r * time) * DStat.NormDist(-d2);
            return rho;
        }
        public static void option_price_partials_call_black_scholes(double S, 
            double K, double r, double sigma, double time, out double Delta, 
            out double Gamma, out double Theta, out double Vega, out double Rho)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) 
                + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            Delta = DStat.NormDist(d1);
            Gamma = DStat.NormDist(d1) / (S * sigma * time_sqrt);
            Theta = -(S * sigma * DStat.NormDist(d1)) / (2 * time_sqrt) 
                - r * K * Math.Exp(-r * time) * DStat.NormDist(d2);
            Vega = S * time_sqrt * DStat.NormDist(d1);
            Rho = K * time * Math.Exp(-r * time) * DStat.NormDist(d2);
        }
        public static void option_price_partials_put_black_scholes(double S, 
            double K, double r, double sigma, double time, out double Delta,
            out double Gamma, out double Theta, out double Vega, out double Rho)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) 
                + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            Delta = -DStat.NormDist(-d1);
            Gamma = DStat.NormDist(d1) / (S * sigma * time_sqrt);
            Theta = -(S * sigma * DStat.NormDist(d1)) / (2 * time_sqrt) 
                + r * K * Math.Exp(-r * time) * DStat.NormDist(-d2);
            Vega = S * time_sqrt * DStat.NormDist(d1);
            Rho = -K * time * Math.Exp(-r * time) * DStat.NormDist(-d2);
        }

        public static double option_price_implied_volatility_call_black_scholes_bisections(
            double S, double K, double r, double time, double option_price)
        {
            if (option_price < 0.99 * (S - K * Math.Exp(-time * r)))
            {  // check for arbitrage violations. Option price is too low if this happens
                return 0.0; 
            };

            // simple binomial search for the implied volatility.
            // relies on the value of the option increasing in volatility
            const double ACCURACY = 1.0e-5; // make this smaller for higher accuracy
            const int MAX_ITERATIONS = 100;
            const double HIGH_VALUE = 1e10;
            const double ERROR = -1e40;

            // want to bracket sigma. first find a maximum sigma by finding a sigma
            // with a estimated price higher than the actual price.
            double sigma_low = 1e-5;
            double sigma_high = 0.3;
            double price = option_price_call_black_scholes(S, K, r, sigma_high, time);
            while (price < option_price)
            {
                sigma_high = 2.0 * sigma_high; // keep doubling.
                price = option_price_call_black_scholes(S, K, r, sigma_high, time);
                if (sigma_high > HIGH_VALUE) return ERROR; // panic, something wrong.
            };
            for (int i = 0; i < MAX_ITERATIONS; i++)
            {
                double sigma = (sigma_low + sigma_high) * 0.5;
                price = option_price_call_black_scholes(S, K, r, sigma, time);
                double test = (price - option_price);
                if (Math.Abs(test) < ACCURACY) { return sigma; };
                if (test < 0.0) { sigma_low = sigma; }
                else { sigma_high = sigma; }
            };
            return ERROR;
        }
        
        public static double option_price_implied_volatility_put_black_scholes_bisections(
            double S, double K, double r, double time, double option_price)
        {
            if (option_price < 0.99 * (S - K * Math.Exp(-time * r)))
            {  // check for arbitrage violations. Option price is too low if this happens
                return 0.0;
            };

            // simple binomial search for the implied volatility.
            // relies on the value of the option increasing in volatility
            const double ACCURACY = 1.0e-5; // make this smaller for higher accuracy
            const int MAX_ITERATIONS = 100;
            const double HIGH_VALUE = 1e10;
            const double ERROR = -1e40;

            // want to bracket sigma. first find a maximum sigma by finding a sigma
            // with a estimated price higher than the actual price.
            double sigma_low = 1e-5;
            double sigma_high = 0.3;
            double price = option_price_put_black_scholes(S, K, r, sigma_high, time);
            while (price < option_price)
            {
                sigma_high = 2.0 * sigma_high; // keep doubling.
                price = option_price_put_black_scholes(S, K, r, sigma_high, time);
                if (sigma_high > HIGH_VALUE) return ERROR; // panic, something wrong.
            };
            for (int i = 0; i < MAX_ITERATIONS; i++)
            {
                double sigma = (sigma_low + sigma_high) * 0.5;
                price = option_price_call_black_scholes(S, K, r, sigma, time);
                double test = (price - option_price);
                if (Math.Abs(test) < ACCURACY) { return sigma; };
                if (test < 0.0) { sigma_low = sigma; }
                else { sigma_high = sigma; }
            };
            return ERROR;
        }

        public static double option_price_implied_volatility_call_black_scholes_newton(
            double S, double K, double r, double time, double option_price)
        {
            if (option_price < 0.99 * (S - K * Math.Exp(-time * r)))
            {  // check for arbitrage violations. Option price is too low if this happens
                return 0.0;
            };

            const int MAX_ITERATIONS = 100;
            const double ACCURACY = 1.0e-5;
            double t_sqrt = Math.Sqrt(time);

            double sigma = (option_price / S) / (0.398 * t_sqrt);    // find initial value
            for (int i = 0; i < MAX_ITERATIONS; i++)
            {
                double price = option_price_call_black_scholes(S, K, r, sigma, time);
                double diff = option_price - price;
                if (Math.Abs(diff) < ACCURACY) return sigma;
                double d1 = (Math.Log(S / K) + r * time) / (sigma * t_sqrt) + 0.5 * sigma * t_sqrt;
                double vega = S * t_sqrt * DStat.NormDist(d1);
                sigma = sigma + diff / vega;
            };
            return -99e10;  // something screwy happened, should throw exception
        }
        
        public static double option_price_implied_volatility_put_black_scholes_newton(
            double S, double K, double r, double time, double option_price)
        {
            if (option_price < 0.99 * (S - K * Math.Exp(-time * r)))
            {  // check for arbitrage violations. Option price is too low if this happens
                return 0.0;
            };

            const int MAX_ITERATIONS = 100;
            const double ACCURACY = 1.0e-5;
            double t_sqrt = Math.Sqrt(time);

            double sigma = (option_price / S) / (0.398 * t_sqrt);    // find initial value
            for (int i = 0; i < MAX_ITERATIONS; i++)
            {
                double price = option_price_put_black_scholes(S, K, r, sigma, time);
                double diff = option_price - price;
                if (Math.Abs(diff) < ACCURACY) return sigma;
                double d1 = (Math.Log(S / K) + r * time) / (sigma * t_sqrt) + 0.5 * sigma * t_sqrt;
                double vega = S * t_sqrt * DStat.NormDist(d1);
                sigma = sigma + diff / vega;
            };
            return -99e10;  // something screwy happened, should throw exception
        }
    }
    public static class BSMOption_Barrier
    {
        // Barrier Option (障礙式選擇權) //
        public static double call_price_down_and_in(double S, double K, double H, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double lambda = r / Math.Pow(sigma, 2) + 0.5;
            double y = (Math.Log(Math.Pow(H, 2) / (S * K)) / (sigma * time_sqrt)) + lambda * sigma * time_sqrt;
            double x1 = Math.Log(S / H) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double y1 = Math.Log(H / S) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double ans;
            double call = S * DStat.NormDist(d1) - K * Math.Exp(-r * time) * DStat.NormDist(d2);
            if (H < K)
            {
                ans = S * Math.Pow(H / S, (2 * lambda)) * DStat.NormDist(y) - K * Math.Exp(-r * time) *
                Math.Pow(H / S, (2 * lambda - 2)) * DStat.NormDist(y - sigma * time_sqrt);
            }
            else
            {
                ans = (S * DStat.NormDist(d1) - K * Math.Exp(-r * time) * DStat.NormDist(d2))-(S * DStat.NormDist(x1) - K * Math.Exp(-r * time) * DStat.NormDist(x1 - sigma * time_sqrt)-
                    S * Math.Pow(H / S, 2 * lambda) * DStat.NormDist(y1)+ K * Math.Exp(-r * time)* 
                    Math.Pow(H / S, 2 * lambda -2)* DStat.NormDist(y1 - sigma * time_sqrt));
            }
            if (ans > call)
            {
                ans = call;
            }
            
            if (ans < 0)
            {
                return 0;
            }

            return ans;
        }
        public static double call_price_down_and_out(double S, double K, double H, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double lambda = r / Math.Pow(sigma, 2) + 0.5;
            double y = (Math.Log(Math.Pow(H, 2) / (S * K)) / (sigma * time_sqrt)) + lambda * sigma * time_sqrt;
            double x1 = Math.Log(S / H) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double y1 = Math.Log(H / S) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double ans;
            double call = S * DStat.NormDist(d1) - K * Math.Exp(-r * time) * DStat.NormDist(d2);
            if (H < K)
            {
                ans =(S * DStat.NormDist(d1) - K * Math.Exp(-r * time) * DStat.NormDist(d2)) -
                (S * Math.Pow(H / S, 2 * lambda) * DStat.NormDist(y) -
                K * Math.Exp(-r * time) * Math.Pow(H / S, (2 * lambda - 2)) * DStat.NormDist(y - sigma * time_sqrt));
            }
            else
            {
                ans = S * DStat.NormDist(x1) - K * Math.Exp(-r * time) * DStat.NormDist(x1 - sigma * time_sqrt) -
                    S * Math.Pow(H / S, 2 * lambda) * DStat.NormDist(y1) + K * Math.Exp(-r * time) *
                    Math.Pow(H / S, 2 * lambda - 2) * DStat.NormDist(y1 - sigma * time_sqrt);
            }
            if (ans > call)
            {
                ans = call;
            }
            if (ans < 0)
            {
                return 0;
            }

            return ans;
        }

        public static double call_price_up_and_in(double S, double K, double H, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double lambda = r / Math.Pow(sigma, 2) + 0.5;
            double y = (Math.Log(Math.Pow(H, 2) / (S * K)) / (sigma * time_sqrt)) + lambda * sigma * time_sqrt;
            double x1 = Math.Log(S / H) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double y1 = Math.Log(H / S) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double ans;
            double call = S * DStat.NormDist(d1) - K * Math.Exp(-r * time) * DStat.NormDist(d2);
            if (H > K)
            { 
               ans = S* DStat.NormDist(x1) - K * Math.Exp(-r * time) * DStat.NormDist(x1 - sigma * time_sqrt) -
               S * Math.Pow(H / S, 2 * lambda) * (DStat.NormDist(-y) - DStat.NormDist(-y1)) +
               K * Math.Exp(-r * time) * Math.Pow(H / S, (2 * lambda - 2)) *
               (DStat.NormDist(-y + sigma * time_sqrt) - DStat.NormDist(-y1 + sigma * time_sqrt));
            }
            else
            {
                ans = S * DStat.NormDist(d1) - K * Math.Exp(-r * time) * DStat.NormDist(d2);
            }
            if (ans > call)
            {
                ans = call;
            }
            if (ans < 0)
            {
                return 0;
            }

            return ans;
        }

        public static double call_price_up_and_out(double S, double K, double H, double r, double sigma, double time)
        {

            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double lambda = r / Math.Pow(sigma, 2) + 0.5;
            double y = (Math.Log(Math.Pow(H, 2) / (S * K)) / (sigma * time_sqrt)) + lambda * sigma * time_sqrt;
            double x1 = Math.Log(S / H) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double y1 = Math.Log(H / S) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double ans;
            double call = S * DStat.NormDist(d1) - K * Math.Exp(-r * time) * DStat.NormDist(d2);
            if (H > K)
            {
                ans = (S * DStat.NormDist(d1) - K * Math.Exp(-r * time) * DStat.NormDist(d2)) - S *
                DStat.NormDist(x1) - K * Math.Exp(-r * time) * DStat.NormDist(x1 - sigma * time_sqrt) -
                S * Math.Pow(H / S, 2 * lambda) * (DStat.NormDist(-y) - DStat.NormDist(-y1)) +
                K * Math.Exp(-r * time) * Math.Pow(H / S, (2 * lambda - 2)) *
                (DStat.NormDist(-y + sigma * time_sqrt) - DStat.NormDist(-y1 + sigma * time_sqrt));
            }
            else
            {
                ans = 0;
            }
            if (ans > call)
            {
                ans = call;
            }
            if (ans < 0)
            {
                return 0;
            }

            return ans;
        }

        public static double put_price_up_and_in(double S, double K, double H, double r, double sigma, double time)
        {

            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double lambda = r / Math.Pow(sigma, 2) + 0.5;
            double y = (Math.Log(Math.Pow(H, 2) / (S * K)) / (sigma * time_sqrt)) + lambda * sigma * time_sqrt;
            double x1 = Math.Log(S / H) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double y1 = Math.Log(H / S) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double ans;
            double put = K * Math.Exp(-r * time) * DStat.NormDist(-d2) - S * DStat.NormDist(-d1);
            if (H > K)
            {
                ans = -S * Math.Pow(H / S, 2 * lambda) * DStat.NormDist(-y) + K * Math.Exp(-r * time) *
                Math.Pow(H / S, 2 * lambda - 2) * DStat.NormDist(-y + sigma * time_sqrt);
            }
            else
            {
                ans = (K * Math.Exp(-r * time) * DStat.NormDist(-d2) - S * DStat.NormDist(-d1)) - 
                    (-S* DStat.NormDist(-x1)+ K * Math.Exp(-r * time)* DStat.NormDist(-x1 + sigma * time_sqrt)+
                    S* Math.Pow(H / S, 2 * lambda)* DStat.NormDist(-y1)- K * Math.Exp(-r * time)* 
                    Math.Pow(H / S, 2 * lambda-2)* DStat.NormDist(-y1 + sigma * time_sqrt));
            }
            if (ans > put)
            {
                ans = put;
            }
            if (ans < 0)
            {
                return 0;
            }

            return ans;
        }

        public static double put_price_up_and_out(double S, double K, double H, double r, double sigma, double time)
        {

            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double lambda = r / Math.Pow(sigma, 2) + 0.5;
            double y = (Math.Log(Math.Pow(H, 2) / (S * K)) / (sigma * time_sqrt)) + lambda * sigma * time_sqrt;
            double x1 = Math.Log(S / H) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double y1 = Math.Log(H / S) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double ans;
            double put = K * Math.Exp(-r * time) * DStat.NormDist(-d2) - S * DStat.NormDist(-d1);
            if (H > K)
            {
                ans = (K * Math.Exp(-r * time) * DStat.NormDist(-d2) - S * DStat.NormDist(-d1)) -(- S * Math.Pow(H / S, 2 * lambda) * DStat.NormDist(-y) + K * Math.Exp(-r * time) *
                Math.Pow(H / S, 2 * lambda - 2) * DStat.NormDist(-y + sigma * time_sqrt));
            }
            else
            {
                ans = (K * Math.Exp(-r * time) * DStat.NormDist(-d2) - S * DStat.NormDist(-d1)) -
                (-S * Math.Pow(H / S, 2 * lambda) * DStat.NormDist(-y) + K * Math.Exp(-r * time) *
                Math.Pow(H / S, 2 * lambda - 2) * DStat.NormDist(-y + sigma * time_sqrt));
            }
            if (ans > put)
            {
                ans = put;
            }
            if (ans < 0)
            {
                return 0;
            }

            return ans;
        }

        public static double put_price_down_and_in(double S, double K, double H, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double lambda = r / Math.Pow(sigma, 2) + 0.5;
            double y = (Math.Log(Math.Pow(H, 2) / (S * K)) / (sigma * time_sqrt)) + lambda * sigma * time_sqrt;
            double x1 = Math.Log(S / H) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double y1 = Math.Log(H / S) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double ans;
            double put = K * Math.Exp(-r * time) * DStat.NormDist(-d2) - S * DStat.NormDist(-d1);
            if (H < K)
            {
                ans = -S * DStat.NormDist(-x1) + K * Math.Exp(-r * time) * DStat.NormDist(-x1 + sigma * time_sqrt) +
                S * Math.Pow(H / S, 2 * lambda) * (DStat.NormDist(y) - DStat.NormDist(y1)) -
                K * Math.Exp(-r * time) * Math.Pow(H / S, (2 * lambda - 2)) *
                (DStat.NormDist(y - sigma * time_sqrt) - DStat.NormDist(y1 - sigma * time_sqrt));
            }
            else
            {
                ans = (K * Math.Exp(-r * time) * DStat.NormDist(-d2) - S * DStat.NormDist(-d1));
            }
            if (ans > put)
            {
                ans = put;
            }
            if (ans < 0)
            {
                return 0;
            }

            return ans;
        }

        public static double put_price_down_and_out(double S, double K, double H, double r, double sigma, double time)
        {
            double time_sqrt = Math.Sqrt(time);
            double d1 = (Math.Log(S / K) + r * time) / (sigma * time_sqrt) + 0.5 * sigma * time_sqrt;
            double d2 = d1 - (sigma * time_sqrt);
            double lambda = r / Math.Pow(sigma, 2) + 0.5;
            double y = (Math.Log(Math.Pow(H, 2) / (S * K)) / (sigma * time_sqrt)) + lambda * sigma * time_sqrt;
            double x1 = Math.Log(S / H) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double y1 = Math.Log(H / S) / (sigma * time_sqrt) + lambda * sigma * time_sqrt;
            double ans;
            double put = K * Math.Exp(-r * time) * DStat.NormDist(-d2) - S * DStat.NormDist(-d1);
            if (H < K)
            {
                ans = (K * Math.Exp(-r * time) * DStat.NormDist(-d2) - S * DStat.NormDist(-d1)) -
                (-S * DStat.NormDist(-x1) + K * Math.Exp(-r * time) * DStat.NormDist(-x1 + sigma * time_sqrt) +
                S * Math.Pow(H / S, 2 * lambda) * (DStat.NormDist(y) - DStat.NormDist(y1)) -
                K * Math.Exp(-r * time) * Math.Pow(H / S, (2 * lambda - 2)) *
                (DStat.NormDist(y - sigma * time_sqrt) - DStat.NormDist(y1 - sigma * time_sqrt)));
            }
            else
            {
                ans = 0;
            }
            if (ans > put)
            {
                ans = put;
            }
            if (ans < 0){
                return 0;
            }

            return ans;
        }
    }

}
